import SubpageHeader from "../../SubpageHeader"; export const metadata={title:"Reports | CDPGP"};
export default function Page(){return <main><SubpageHeader/><section className="collection-hero"><small>Evidence & data</small><h1>Reports.</h1><p>Research reports, surveys and launch materials will be published here. / 研究报告、调查及发布资料将陆续上线。</p></section></main>}

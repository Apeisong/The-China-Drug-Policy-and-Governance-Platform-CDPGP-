import SubpageHeader from "../../SubpageHeader"; export const metadata={title:"Social Work Practices | CDPGP"};
export default function Page(){return <main><SubpageHeader/><section className="collection-hero"><small>Practice knowledge</small><h1>Social Work Practices.</h1><p>Practice models and frontline experience in anti-drug social work. / 禁毒社会工作的实践模式与一线经验。</p></section></main>}

import SubpageHeader from "../../SubpageHeader"; export const metadata={title:"Projects | CDPGP"};
export default function Page(){return <main><SubpageHeader/><section className="collection-hero"><small>Active & completed research</small><h1>Projects.</h1><p>CDPGP research projects will be introduced here progressively. / 平台研究项目将陆续发布。</p></section></main>}

import SubpageHeader from "../../SubpageHeader";
export const metadata={title:"Policy Briefs & Library | CDPGP"};
const groups=[
{name:"Drug Policy｜毒品政策",items:[
["全国人民代表大会常务委员会关于禁毒的决定","1990年通过；2008年《禁毒法》施行时废止","https://gongbao.court.gov.cn/Details/a8ac4a3940fa55fcbe8605efca3952.html"],
["强制戒毒办法","国务院令第170号，1995年施行；2011年《戒毒条例》施行时废止","https://www.taicang.gov.cn/taicang/tcgaj05/200803/77b3b5d5c0c04c9093f846b9e188fee0.shtml"],
["麻醉药品和精神药品管理条例","2005年公布；2013、2016、2024年修订","https://xzfg.moj.gov.cn/front/law/detail?LawID=1744"],
["易制毒化学品管理条例","2005年公布；2014、2016、2018年修订","https://xzfg.moj.gov.cn/front/law/detail?LawID=1298"],
["中华人民共和国禁毒法","2007年通过，2008年6月1日起施行","https://www.npc.gov.cn/zgrdw/wxzl/gongbao/2008-02/23/content_1462412.htm"],
["戒毒条例","2011年公布，2018年修订","https://xzfg.moj.gov.cn/front/law/detail?LawID=1146"],
["吸毒成瘾认定办法","2011年制定，2016年修改，2017年4月1日起施行","https://ncga.nc.gov.cn/ncgaj/zfgk/201701/66235493b07f406988dd3ff8d8da5206.shtml"],
["戒毒药物维持治疗工作管理办法","国卫疾控发〔2014〕91号，2015年2月1日起实施","https://www.nhc.gov.cn/jkj/c100063/201701/b24317b4f33c4248aa0ff79d6c1795d7.shtml"],
["中华人民共和国治安管理处罚法","2025年修订；包含非法持有少量毒品、提供毒品、吸食或注射毒品及容留吸毒等规定","https://www.npc.gov.cn/npc/c2/c30834/202506/t20250627_446254.html"]]},
{name:"HIV/AIDS Policy & Plans｜艾滋病政策与规划",items:[
["中国预防与控制艾滋病中长期规划（1998—2010年）","国发〔1998〕38号","https://www.shaanxi.gov.cn/zfxxgk/zfgb/1998/d24q_4490/200806/t20080626_1635913_wap.html"],
["中国遏制与防治艾滋病行动计划（2001—2005年）","国办发〔2001〕40号","https://zfgb.fujian.gov.cn/7793"],
["国务院关于切实加强艾滋病防治工作的通知","国发〔2004〕7号；“四免一关怀”时期重要政策","https://www.nhc.gov.cn/bgt/pw10405/200406/c35f35633c6c4eaf9e2286489cba8a7b.shtml"],
["艾滋病防治条例","国务院令第457号，2006年施行，2019年修订","https://xzfg.moj.gov.cn/front/law/detail?LawID=1318"],
["中国遏制与防治艾滋病行动计划（2006—2010年）","国办发〔2006〕13号","https://www.shaanxi.gov.cn/zfxxgk/zfgb/2006/d8q_4274/200806/t20080626_1639081.html"],
["中国遏制与防治艾滋病“十二五”行动计划","国办发〔2012〕4号","https://www.nhc.gov.cn/jkj/c100063/201203/f83a08e8bd184ccab3b9c041ff4e0609.shtml"],
["中国遏制与防治艾滋病“十三五”行动计划","国办发〔2017〕8号","https://app.www.gov.cn/govdata/gov/201702/05/398469/article.html"],
["遏制艾滋病传播实施方案（2019—2022年）","国卫疾控发〔2019〕54号，十部门联合制定","https://www.nhc.gov.cn/jkj/c100063/201910/12cce85eb81d45f68961c6294585db21.shtml"],
["中国遏制与防治艾滋病规划（2024—2030年）","国办发〔2024〕51号；Current National Plan","https://www.ndcpa.gov.cn/jbkzzx/c100081/common/content/content_1921830274755629056.html"]]},
{name:"Community Corrections｜社区矫正",items:[
["社区矫正实施办法","司发通〔2012〕12号；2020年新实施办法对其修订","https://www.gov.cn/gongbao/content/2012/content_2161727.htm"],
["关于全面推进社区矫正工作的意见","2014年；从试点走向全面推进的重要政策节点","https://www.moj.gov.cn/pub/sfbgwapp/zwgk/tzggApp/202105/t20210517_395413.html"],
["关于组织社会力量参与社区矫正工作的意见","2014年；涉及社会组织、社会工作、就业、就学、社会救助及社会保险","https://www.moj.gov.cn/pub/sfbgwapp/zwgk/tzggApp/202105/t20210517_395412.html"],
["中华人民共和国社区矫正法","2019年通过，2020年7月1日起施行","https://www.npc.gov.cn/npc/c2/c30834/201912/t20191231_304419.html"],
["中华人民共和国社区矫正法实施办法","2020年；与《社区矫正法》配套实施","https://www.moj.gov.cn/pub/sfbgwapp/zwgk/tzggApp/202105/t20210517_395851.html"]]}];
export default function PolicyBriefs(){return <main><SubpageHeader/><section className="collection-hero policy-collection"><small>Policy briefs & primary sources</small><h1>Policy Library.</h1><p>23 key documents across Chinese drug policy, HIV/AIDS policy and community corrections.</p></section><section className="policy-groups">{groups.map((g)=><section key={g.name}><div className="policy-group-title"><h2>{g.name}</h2><span>{g.items.length} documents</span></div><div>{g.items.map(([title,note,url],i)=><a href={url} target="_blank" rel="noreferrer" key={title}><b>{String(i+1).padStart(2,"0")}</b><h3>{title}</h3><p>{note}</p><span>Official source ↗</span></a>)}</div></section>)}</section></main>}

import SubpageHeader from "../SubpageHeader";

export const metadata = { title: "Research & Policy | CDPGP" };

const outputs = [
  ["Articles", "2020—2026", "Peer-reviewed articles and scholarly commentary, organised by year.", "/work/articles"],
  ["Policy Briefs", "23 policy documents", "Chinese drug, HIV/AIDS and community corrections policy.", "/work/policy-briefs"],
  ["Projects", "Active research", "Current and completed research projects across the CDPGP network.", "/work/projects"],
  ["Reports", "Evidence & data", "Research reports, surveys and launch materials.", "/work/reports"],
  ["Monographs", "Books", "Books and other long-form research publications.", "/work/monographs"],
  ["Social Work Practices", "Practice", "Practice models and frontline experience in anti-drug social work.", "/work/social-work-practices"],
];
const policies = [
  ["Drug Policy", "中华人民共和国禁毒法", "2008—", "https://www.npc.gov.cn/zgrdw/wxzl/gongbao/2008-02/23/content_1462412.htm"],
  ["Drug Policy", "戒毒条例", "2011 · 2018修订", "https://xzfg.moj.gov.cn/front/law/detail?LawID=1146"],
  ["Drug Policy", "麻醉药品和精神药品管理条例", "2005 · 2024修订", "https://xzfg.moj.gov.cn/front/law/detail?LawID=1744"],
  ["Drug Policy", "易制毒化学品管理条例", "2005 · 2018修订", "https://xzfg.moj.gov.cn/front/law/detail?LawID=1298"],
  ["Drug Policy", "吸毒成瘾认定办法", "2011 · 2016修改", "https://ncga.nc.gov.cn/ncgaj/zfgk/201701/66235493b07f406988dd3ff8d8da5206.shtml"],
  ["Drug Policy / HIV", "戒毒药物维持治疗工作管理办法", "2015—", "https://www.nhc.gov.cn/jkj/c100063/201701/b24317b4f33c4248aa0ff79d6c1795d7.shtml"],
  ["HIV/AIDS", "中国遏制与防治艾滋病规划（2024—2030年）", "Current national plan", "https://www.ndcpa.gov.cn/jbkzzx/c100081/common/content/content_1921830274755629056.html"],
  ["HIV/AIDS", "艾滋病防治条例", "2006 · 2019修订", "https://xzfg.moj.gov.cn/front/law/detail?LawID=1318"],
  ["Community Corrections", "中华人民共和国社区矫正法", "2020—", "https://www.npc.gov.cn/npc/c2/c30834/201912/t20191231_304419.html"],
  ["Community Corrections", "中华人民共和国社区矫正法实施办法", "2020—", "https://www.moj.gov.cn/pub/sfbgwapp/zwgk/tzggApp/202105/t20210517_395851.html"],
];

export default function WorkPage(){return <main><SubpageHeader/><section className="subpage-hero work-hero"><small>Research · Policy · Practice</small><h1>Explore our work.</h1><p>研究成果与政策资料</p></section><section className="work-output"><div className="section-label"><span>01</span>Publications & outputs</div><div className="work-output-grid">{outputs.map(([title,meta,copy,url])=><a href={url} key={title}><small>{meta}</small><h2>{title}</h2><p>{copy}</p><span>Explore / 查看 ↗</span></a>)}</div></section><section className="policy section" id="policy"><div className="section-label light"><span>02</span>Policy library / 政策资料库</div><div className="section-content"><div className="policy-heading"><h2>Key policy documents, in one place.</h2><p>A curated gateway to primary legal and government sources covering drug policy, HIV/AIDS and community corrections.<br/>集中链接毒品政策、艾滋病政策与社区矫正的一手法律及政府来源。</p></div><a className="policy-page-link" href="/work/policy-briefs">Browse all 23 policy documents / 查看全部23项政策 ↗</a></div></section></main>}

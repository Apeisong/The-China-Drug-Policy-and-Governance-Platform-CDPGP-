import SubpageHeader from "../../SubpageHeader";
export const metadata={title:"Articles | CDPGP"};
const articles:Record<string,string[]>={
"2026":[
"Song, A. & Chen, A. ‘Stigmatisation for poppers use is a sexualised mode of governance’: Lived Experiences and Counter-Narratives of Gay Men Who Use Poppers in Mainland China. International Journal of Drug Policy.",
"Song, A. ‘New Barefoot Doctors’: How Social Workers Navigate HIV Care and Structural Marginality in Yi Ethnic Minority Communities. Social Science & Medicine.",
"Su, G., Jiang, J., & Song, A. Rehabilitation Frames: How Offenders Understand and Navigate Compliance Requirements in Chinese Community Corrections. Crime, Media, Culture.",
"Song, A. & Tong, Y. Weak Chemsex as Cultural Scripts: Understanding How Chinese Gay Men Narrative Drug Use in Sexual Pleasure. Sexualities.",
"Song, A. & Jiang, J. Pride and Prejudice: Strategic Coupling of Punishment and Welfare in Chinese Community Corrections. Theoretical Criminology.",
"Tong, Y., Song, A., & Su, Z. ‘We’re Experiencing Digital Death’: Chinese People Who Used Heroin in Community-Based Rehabilitation. Social Inclusion, 14.",
"Song, A., Ma, L., & Liu, Z. Revisiting Professional Autonomy and Structural Constraints: Relational Work in Anti-Drug Social Work. International Social Work.",
"Song, A. & He, J. ‘Be Mom, for Mom’: Anti-authority Recovery Narratives of Females Who Use Drugs in China. Contemporary Drug Problems.",
"Song, A. & Jiang, J. Surviving in the Cracks: How People Who Use Drugs Navigate Police-Led Rehabilitation in China. Journal of Drug Issues.",
"Song, A., He, J., & Cui, K. From Legal Estrangement to Legal Mobilisation: Navigating the Processual Professional Autonomy of Antidrug Social Workers. British Journal of Social Work.",
"Song, A., Dertadian, G. C., & He, J. Recovery Capital in Chinese Drug Rehabilitation: Exploring Person-Centred and Community-Based Perspectives. Drug & Alcohol Review, 45(1)."
],
"2025":[
"He, J., Liu, J., & Song, A. ‘It is Time... to End Everything’: Discontinue Medication Choices and Narratives Among Elderly HIV-Positive Yi Women. Social Science & Medicine.",
"Song, A. & Tong, Y. Digitalising Violence: Decoding Management in the Rehabilitation of People Who Use Drugs. Punishment & Society.",
"Song, A. & He, J. Framing ‘Chemsexism’: Chinese Gay Men Navigating Stigma and Labelling. Journal of Homosexuality, 1–23.",
"Song, A., He, J., & Liu, Z. Systemic Neglect Hidden Behind Tolerance: The Reproduction of Vulnerability Among Aging Heroin Users Within Community-Based Rehabilitation. Innovation in Aging.",
"Song, A. & Jiang, J. Coercive Rehabilitation and Therapeutic Control: How the Police Navigate the Penal-Welfare Nexus in Chinese Drug Governance. Policing & Society.",
"Jiang, J. & Song, A. Making the Enforcement Rehabilitative: Penal Welfarism and Emotional Labour of Police Officers in Chinese Drug Policing. Criminology & Criminal Justice.",
"Song, A. & He, J. ‘Nothing but...stuff being played with’: Body-constructed Narratives of Drug-Trafficking Young Girls. Journal of Ethnicity in Substance Abuse.",
"Song, A., Li, K., Han, P., & Yao, H. Tracing, Stabilising, Storytelling: How to Assemble Recovery for People Who Have Mental Health Disorders. Journal of Social Work."
],
"2024":["Song, A., Zhu, C., & Liu, Z. ‘No Ability to Choose Freedom’: A Qualitative Study of People Who Use Drugs’ Experiences of Compulsory Isolation Treatment. Addiction Research & Theory.","Jiang, J., & Song, A. Strong Control and Weak Service: Enforcing Drug Treatment in China. Journal of Drug Issues, 55(3), 379–400.","Song, A. Multiple Logics and Inconsistent Identities of People Who Use Drugs. PKU Journal of Sociology, 3(1), 90."],
"2023":["Wu, J., Xia, Y., & Song, A. Milestones and Current Dilemmas: Evaluation of Sentencing Standardisation for Illegal Possession of Drugs in China. Laws, 12(3), 53.","Song, A., Zhang, Z., & Liu, Z. Psychoactive Comfort Products or Snacks: How Chinese Young Adults Perceive the Potentially Addictive Nature of E-Cigarettes. Healthcare, 11(10), 1440."],
"2022":["Li, D., & Song, A. Drug Use Disorder and Family Politics Evolution: How Can Chinese PWUD Families Quit Drugs? Journal of Ethnicity in Substance Abuse, 23(3), 586–611.","Song, A., & Liu, Z. ‘Returning to Ordinary Citizenship’: A Qualitative Study of Chinese PWUD’s Self-Management Strategies and Disengagement Model of Identity. Behavioral Sciences, 12(8), 258."],
"2021":["Song, A., & Ren, Z. Distressing Experiences of Chinese Schooling Winners: School Infiltration in Chinese Family Parenting. Cogent Education, 9(1), 2034245."],
"2020":["Song, A. ‘Quit Masturbation, Change Failure’: The Process, Essence, and Reflection of Identity Construction in the Abstinence Internet Organisation. Sexual Addiction & Compulsivity, 27(3–4), 236–273."]};
export default function Articles(){return <main><SubpageHeader/><section className="collection-hero"><small>Publications / 研究成果</small><h1>Articles.</h1></section><section className="bibliography">{["2026","2025","2024"].map((year)=><section key={year}><h2>{year}</h2><ol>{articles[year].map((x,i)=><li key={i}>{x}</li>)}</ol></section>)}</section></main>}

"use client";

import Image from "next/image";
import { useEffect, useState } from "react";

type Lang = "en" | "zh";

const content = {
  en: {
    nav: ["About", "People", "Publications", "Policy Briefs", "Events & News", "Resources", "Contact"],
    eyebrow: "Evidence · Dialogue · Collaboration",
    title: "Advancing rigorous, independent research on drug policy and governance in China.",
    intro: "Connecting drug control, public health, criminal justice, treatment and rehabilitation through interdisciplinary, policy-relevant research.",
    explore: "Our research",
    about: "About the platform",
    aboutTitle: "Critical research for a changing policy landscape.",
    aboutCopy: "The China Drug Policy and Governance Platform (CDPGP) is an independent research platform dedicated to advancing evidence-based, critical, and interdisciplinary research on drug policy and governance. The Platform also promotes research on the social inclusion, social integration, and rehabilitation of people who use drugs, alongside broader questions of addiction, recovery, and the ways in which these experiences are shaped by systems of governance.",
    principle: "Our guiding principle",
    quote: "Policy becomes stronger when evidence is shared, perspectives meet, and knowledge can move into practice.",
    focus: "Research areas",
    focusTitle: "Nine connected fields of inquiry.",
    areas: [
      ["01", "Drug Policy", "Law, policy development and evidence-informed reform."],
      ["02", "Drug Governance", "Institutions, implementation and systems of control."],
      ["03", "Treatment & Recovery", "Care, recovery pathways and lived experience."],
      ["04", "Criminal Justice", "Drug control across policing, courts and corrections."],
      ["05", "Governance of Addiction", "How addiction is defined, managed and governed."],
      ["06", "Community Rehabilitation", "Community-based support, inclusion and reintegration."],
      ["07", "Penal Welfarism", "The intersection of punishment, welfare and care."],
      ["08", "Drugs & Media", "How drugs, drug use and policy are represented in media and public discourse."],
      ["09", "Anti-drug Social Work", "Professional practice and social responses to drug use."],
    ],
    people: "People",
    peopleTitle: "An interdisciplinary platform, built person by person.",
    peopleCopy: "We are introducing the CDPGP community progressively. Dr Apei Song’s profile is available now; further profiles will follow.",
    role: "Research Fellow",
    bio: "Dr Apei Song conducts research on drug policy, governance and evidence translation within the CDPGP research community.",
    interests: "Drug policy · Governance · Evidence translation",
    profile: "View profile",
    joining: "More collaborators",
    joiningCopy: "Profiles coming soon",
    logo: "The story behind our logo",
    logoTitle: "A visual language of connection, evidence and possibility.",
    logoParas: [
      "At its core, interconnected nodes represent the diverse actors involved in drug governance—from government agencies and researchers to healthcare professionals, social organisations and affected communities. Policy is collectively shaped through interaction and shared knowledge.",
      "The bridge and pathway symbolise dialogue between research and practice, and between China and the international community. The open circle suggests a continuous, inclusive policy ecosystem, while its subtle gap leaves room for exchange and future possibilities.",
      "Red accents reflect the Chinese context. Blue conveys professionalism, trust and academic integrity. Together, the elements communicate CDPGP’s mission to foster collaboration and advance drug policy through informed and inclusive approaches.",
    ],
    footer: "Chinese Drug Policy and Governance Platform",
    footerLine: "Understanding policy, caring for communities, and building knowledge together.",
    copyright: "© 2026 CDPGP. All rights reserved.",
  },
  zh: {
    nav: ["关于我们", "团队成员", "研究成果", "政策资料", "活动与新闻", "资源", "联系我们"],
    eyebrow: "循证 · 对话 · 协作",
    title: "推动严谨、独立的中国药物政策与治理研究。",
    intro: "以跨学科、政策相关的研究，连接禁毒、公共卫生、刑事司法、治疗与康复。",
    explore: "我们的研究",
    about: "关于平台",
    aboutTitle: "面向不断变化的政策图景开展批判性研究。",
    aboutCopy: "中国药物政策与治理平台（CDPGP）是一个独立研究平台，致力于推动循证、批判和跨学科的药物政策与治理研究。平台同时关注药物使用者的社会包容、社会融入和康复，以及成瘾、复元及这些经验如何受到治理体系塑造等更广泛的问题。",
    principle: "我们的理念",
    quote: "当证据得以共享、不同观点彼此相遇、知识能够走向实践，政策就会变得更有力量。",
    focus: "研究领域",
    focusTitle: "九个相互关联的研究方向。",
    areas: [
      ["01", "毒品政策", "法律、政策发展与循证改革。"],
      ["02", "药物治理", "制度、政策实施与控制体系。"],
      ["03", "治疗与康复", "照护、复元路径与生命经验。"],
      ["04", "刑事司法", "禁毒工作中的警务、司法与矫正。"],
      ["05", "成瘾治理", "成瘾如何被定义、管理与治理。"],
      ["06", "社区康复", "社区支持、社会包容与重新融入。"],
      ["07", "刑罚福利主义", "惩罚、福利与照护的交汇。"],
      ["08", "毒品与媒体", "媒体与公共话语如何呈现毒品、药物使用及相关政策。"],
      ["09", "禁毒社会工作", "专业实践与社会层面的药物问题应对。"],
    ],
    people: "团队成员",
    peopleTitle: "一个逐步成长的跨学科平台。",
    peopleCopy: "我们将陆续介绍 CDPGP 的成员与合作伙伴。目前已上线 Dr Apei Song 的个人信息，其他成员资料将随后补充。",
    role: "Research Fellow / 研究员",
    bio: "Dr Apei Song 在 CDPGP 研究共同体中开展药物政策、治理与证据转化研究。",
    interests: "药物政策 · 治理 · 证据转化",
    profile: "查看简介",
    joining: "更多合作成员",
    joiningCopy: "资料即将上线",
    logo: "标识寓意",
    logoTitle: "连接、证据与未来可能性的视觉表达。",
    logoParas: [
      "标识核心的互联节点代表参与药物治理的多元主体，包括政府机构、研究人员、医疗卫生专业人员、社会组织和受影响社群。它表明，政策是在互动与知识共享中共同塑造的。",
      "下方的桥梁与路径象征研究和实践之间、中国与国际社会之间的连接和对话。开放的圆环代表持续、包容的政策生态；细微的缺口则为思想交流和未来可能性留出空间。",
      "红色点缀呼应中国语境，蓝色体现专业、信任与学术诚信。整体设计传达 CDPGP 的使命：促进沟通与协作，以知情、包容的方式推动药物政策与治理发展。",
    ],
    footer: "中国药物政策与治理平台",
    footerLine: "理解政策，关怀社群，共同构建知识。",
    copyright: "© 2026 CDPGP。保留所有权利。",
  },
};

const related = [
  ["Articles", "2024—2026", "Peer-reviewed research and commentary"],
  ["Policy Briefs", "Policy library", "Drug, HIV/AIDS and correctional policy"],
  ["Projects", "Active research", "Current CDPGP research projects"],
  ["Reports", "Evidence & data", "Survey reports and research findings"],
  ["Monographs", "Books", "Long-form research publications"],
  ["Social Work Practices", "Practice", "Models and frontline experience"],
];

const policies = [
  ["Drug Policy", "中华人民共和国禁毒法", "2008—", "https://www.npc.gov.cn/zgrdw/wxzl/gongbao/2008-02/23/content_1462412.htm"],
  ["Drug Policy", "戒毒条例", "2011 · rev. 2018", "https://xzfg.moj.gov.cn/front/law/detail?LawID=1146"],
  ["Drug Policy", "麻醉药品和精神药品管理条例", "2005 · rev. 2024", "https://xzfg.moj.gov.cn/front/law/detail?LawID=1744"],
  ["Drug Policy", "易制毒化学品管理条例", "2005 · rev. 2018", "https://xzfg.moj.gov.cn/front/law/detail?LawID=1298"],
  ["Drug Policy", "吸毒成瘾认定办法", "2011 · rev. 2016", "https://ncga.nc.gov.cn/ncgaj/zfgk/201701/66235493b07f406988dd3ff8d8da5206.shtml"],
  ["Drug Policy", "戒毒药物维持治疗工作管理办法", "2015—", "https://www.nhc.gov.cn/jkj/c100063/201701/b24317b4f33c4248aa0ff79d6c1795d7.shtml"],
  ["HIV/AIDS", "中国遏制与防治艾滋病规划（2024—2030年）", "Current national plan", "https://www.ndcpa.gov.cn/jbkzzx/c100081/common/content/content_1921830274755629056.html"],
  ["HIV/AIDS", "艾滋病防治条例", "2006 · rev. 2019", "https://xzfg.moj.gov.cn/front/law/detail?LawID=1318"],
  ["HIV/AIDS", "遏制艾滋病传播实施方案（2019—2022年）", "2019—2022", "https://www.nhc.gov.cn/jkj/c100063/201910/12cce85eb81d45f68961c6294585db21.shtml"],
  ["Community Corrections", "中华人民共和国社区矫正法", "2020—", "https://www.npc.gov.cn/npc/c2/c30834/201912/t20191231_304419.html"],
  ["Community Corrections", "中华人民共和国社区矫正法实施办法", "2020—", "https://www.moj.gov.cn/pub/sfbgwapp/zwgk/tzggApp/202105/t20210517_395851.html"],
  ["Community Corrections", "关于组织社会力量参与社区矫正工作的意见", "2014—", "https://www.moj.gov.cn/pub/sfbgwapp/zwgk/tzggApp/202105/t20210517_395412.html"],
];

export default function HomeClient() {
  const [lang, setLang] = useState<Lang>("en");
  const [menu, setMenu] = useState(false);
  const t = content[lang];
  useEffect(() => { document.documentElement.lang = lang === "zh" ? "zh-CN" : "en"; }, [lang]);
  const navLinks = ["#about", "#people", "/work", "/work#policy", "/events", "/resources", "/resources#contact"];

  return (
    <main>
      <header className="site-header">
        <a className="brand" href="#top" aria-label="CDPGP home">
          <span className="brand-mark"><Image src="/cdpgp-logo.png" alt="" width={1536} height={1024} priority unoptimized /></span>
          <span><b>CDPGP</b><small>{lang === "en" ? "Chinese Drug Policy & Governance Platform" : "中国药物政策与治理平台"}</small></span>
        </a>
        <button className="menu-button" aria-label="Toggle menu" onClick={() => setMenu(!menu)}><i></i><i></i></button>
        <nav className={menu ? "open" : ""} aria-label="Main navigation">
          {t.nav.map((item, i) => <a key={item} href={navLinks[i]} onClick={() => setMenu(false)}>{item}</a>)}
        </nav>
        <button className="language" onClick={() => setLang(lang === "en" ? "zh" : "en")} aria-label="Switch language">
          <span className={lang === "en" ? "active" : ""}>EN</span><em>/</em><span className={lang === "zh" ? "active" : ""}>中</span>
        </button>
      </header>

      <section className="hero" id="top">
        <div className="hero-copy">
          <p className="eyebrow">{t.eyebrow}</p>
          <h1>{t.title}</h1>
          <p className="hero-intro">{t.intro}</p>
          <a className="arrow-link" href="#about">{t.explore}<span>↘</span></a>
        </div>
        <div className="hero-art" aria-hidden="true">
          <div className="orbit orbit-one"></div><div className="orbit orbit-two"></div>
          <span className="node node-a"></span><span className="node node-b"></span><span className="node node-c"></span><span className="node node-d"></span>
          <span className="hero-word">CDPGP</span>
          <span className="side-note">RESEARCH × POLICY × PRACTICE</span>
        </div>
      </section>

      <section className="about section" id="about">
        <div className="section-label"><span>01</span>{t.about}</div>
        <div className="section-content two-col">
          <div><p className="large-copy">{t.aboutCopy}</p><div className="principle"><small>{t.principle}</small><p>“{t.quote}”</p></div></div>
        </div>
      </section>

      <section className="focus section home-focus" id="focus">
        <div className="section-label light"><span>02</span>{t.focus}</div>
        <div className="section-content">
          <div className="focus-grid">{t.areas.map(([n, title, copy]) => <article key={n}><span>{n}</span><h3>{title}</h3><p>{copy}</p></article>)}</div>
        </div>
      </section>

      <section className="people section" id="people">
        <div className="section-label"><span>03</span>{t.people}</div>
        <div className="section-content">
          <div className="people-grid people-uniform">
            <article className="person-card">
              <a className="person-photo" href="/people/apei-song"><Image src="/apei-song.png" alt="Dr Apei Song" fill sizes="(max-width: 700px) 100vw, 33vw" unoptimized /></a>
              <h3>Dr Apei Song</h3><p>Research Fellow</p><a className="person-profile" href="/people/apei-song">View Profile <span>↗</span></a>
            </article>
            {[["Professor Liu Liu","Research Fellow"], ["Professor Zixi Liu","Research Fellow"], ["Associate Professor Xiaotao Wang","Research Fellow"], ["Dr Wan Huang","Research Fellow"], ["Lu Ma","PhD Candidate"], ["Ao Guo","Research Assistant"]].map(([name,role]) => <article className="person-card" key={name}><div className="person-photo person-photo-empty"><span>CDPGP</span></div><h3>{name}</h3><p>{role}</p><span className="person-profile muted">{t.joiningCopy}</span></article>)}
          </div>
        </div>
      </section>

      <section className="home-subscribe"><div><small>CDPGP Newsletter</small><h2>{lang === "en" ? "Follow the work as it develops." : "订阅平台最新进展。"}</h2></div><div><input type="email" placeholder={lang === "en" ? "Email address" : "电子邮箱"} aria-label="Email address"/><button>{lang === "en" ? "Subscribe" : "订阅"} ↗</button></div></section>

      <footer><div><b>CDPGP</b><p>{t.footer}</p></div><p className="footer-line">{t.footerLine}</p><small>{t.copyright}</small></footer>
    </main>
  );
}

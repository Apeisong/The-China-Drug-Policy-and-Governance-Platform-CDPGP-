import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "CDPGP | Chinese Drug Policy and Governance Platform",
  description: "Connecting evidence, policy and people in drug policy and governance.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}

import Link from "next/link";

export default function SubpageHeader() {
  return <header className="subpage-header">
    <Link className="sub-brand" href="/"><b>CDPGP</b><small>Chinese Drug Policy & Governance Platform</small></Link>
    <nav><Link href="/#about">About</Link><Link href="/#people">People</Link><Link href="/work">Publications & Policy</Link><Link href="/events">Events & News</Link><Link href="/resources">Resources</Link><Link href="/resources#contact">Contact</Link></nav>
  </header>;
}

import Image from "next/image";
import Link from "next/link";

export const metadata = { title: "The CDPGP Logo | CDPGP" };

export default function LogoStory() {
  return <main className="detail-page logo-page">
    <header className="detail-header"><Link href="/">← Back to CDPGP</Link><b>CDPGP</b><span>Logo story / 标识寓意</span></header>
    <section className="logo-page-hero"><div><small>Connection · Evidence · Innovation</small><h1>A visual language for an open policy ecosystem.</h1><p>连接 · 证据 · 创新</p></div><div className="logo-page-image"><Image src="/cdpgp-logo.png" alt="CDPGP logo" width={1536} height={1024} unoptimized priority /></div></section>
    <section className="logo-explanation">
      <article><span>01</span><h2>Network / 互联网络</h2><p>Interconnected nodes represent the diverse actors involved in drug governance, including government agencies, researchers, healthcare professionals, social organisations and affected communities.</p><p>互联节点代表参与药物治理的多元主体，包括政府机构、研究人员、医疗卫生专业人员、社会组织和受影响社群。</p></article>
      <article><span>02</span><h2>Bridge & pathway / 桥梁与路径</h2><p>The bridge and pathway symbolise dialogue between research and practice, and between China and the international community. They also suggest ongoing policy development and future possibilities.</p><p>桥梁与路径象征研究和实践之间、中国与国际社会之间的连接和对话，也代表持续发展的政策与未来的可能性。</p></article>
      <article><span>03</span><h2>Open circle / 开放圆环</h2><p>The surrounding circle represents an open and continuous policy ecosystem. Its subtle gap indicates inclusiveness and the exchange of ideas rather than a closed system.</p><p>圆环代表开放、持续的政策生态；细微的缺口体现包容与思想交流，而非封闭的体系。</p></article>
      <article><span>04</span><h2>Colour / 色彩</h2><p>Red accents reflect the Chinese context, while blue conveys professionalism, trust and academic integrity.</p><p>红色点缀呼应中国语境，蓝色体现专业、信任与学术诚信。</p></article>
    </section>
    <footer className="detail-footer"><Link href="/">← Return to the platform / 返回平台首页</Link></footer>
  </main>;
}

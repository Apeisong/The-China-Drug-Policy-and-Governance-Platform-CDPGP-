import Image from "next/image";
import Link from "next/link";

export const metadata = { title: "Dr Apei Song | CDPGP" };

const projects = [
  ["2025—", "高级研究人员", "上海市哲学社会科学规划青年项目“虚实融合视角下青少年越轨行为的生成机制与干预路径研究”", "项目编号：2025ESH003；华东理工大学黄琬主持"],
  ["2025—", "高级研究人员", "上海市白玉兰人才—浦江项目“青少年药物滥用预防政策话语建构与社会认知研究”", "项目编号：25PC011；华东理工大学黄琬主持"],
  ["2024.2—2025.11", "项目负责人", "Making Recovery Happen: How to Understand Citizenship and Employment of Chinese People Who Inject Drugs", "UNSW Faculty of Law & Justice Research and Development Support Fund · AUD 6,000"],
  ["2024.3—2024.8", "项目负责人", "Development and Research Training Grant (DRTG)", "University of New South Wales · AUD 1,500"],
  ["2025.3—2025.8", "项目负责人", "Development and Research Training Grant (DRTG)", "University of New South Wales · AUD 1,500"],
];

const community = [
  ["2024—2025", "The Glen Drug and Alcohol Rehabilitation Centre", "康复咨询"],
  ["2023.9—2024.12", "过瘾同伴小组", "协调员／协助创办"],
  ["2020.10—2021.6", "启福社会服务中心", "实习社工、研究助理"],
  ["2017.12—2018.3", "成都新同伴社会服务中心", "实习社工"],
  ["2016.6—2016.9", "成都爱达讯社会服务中心（法国驻中）", "实习社工"],
];

export default function ApeiSongProfile() {
  return <main className="detail-page">
    <header className="detail-header"><Link href="/">← Back to CDPGP</Link><b>CDPGP</b><span>People / 人员</span></header>
    <section className="profile-hero">
      <div className="detail-portrait"><Image src="/apei-song.png" alt="Dr Apei Song" fill sizes="50vw" unoptimized priority /></div>
      <div className="profile-intro"><small>Research Fellow · 研究员</small><h1>Dr Apei Song</h1><p>Drug policy · Recovery · Punishment · Citizenship</p></div>
    </section>

    <section className="profile-body">
      <aside><span>01</span> Biography</aside>
      <div><h2>Critical, people-centred research on drug policy and social life.</h2><p>Apei Song was awarded his PhD in Criminology and Social Policy from the University of New South Wales. His research sits at the intersection of drug use, recovery, punishment, and citizenship. Adopting critical and people-centred perspectives, his recent work examines the lived experiences of marginalised communities and the social, institutional, and political conditions that shape their everyday lives.</p></div>
    </section>

    <section className="profile-links">
      <a href="mailto:songasa3843@hotmail.com"><small>Email</small><b>songasa3843@hotmail.com</b><span>↗</span></a>
      <a href="https://apeisong-research.netlify.app/" target="_blank" rel="noreferrer"><small>Personal website</small><b>apeisong-research.netlify.app</b><span>↗</span></a>
      <a href="https://scholar.google.com/citations?view_op=list_works&hl=zh-CN&user=ZOWNKoQAAAAJ" target="_blank" rel="noreferrer"><small>Google Scholar</small><b>View publications</b><span>↗</span></a>
      <a href="https://orcid.org/0000-0002-2098-8875" target="_blank" rel="noreferrer"><small>ORCID</small><b>0000-0002-2098-8875</b><span>↗</span></a>
    </section>

    <section className="academic-section education-section">
      <div className="academic-label"><span>02</span><small>Education / 教育经历</small></div>
      <div className="education-list">
        <article><time>2022.8—2026.5</time><div><h3>PhD in Social Policy and Criminology</h3><p>University of New South Wales (UNSW), Australia</p><small>University International Postgraduate Award (UIPA) · Fully funded</small></div></article>
        <article><time>2018—2021</time><div><h3>MA in Sociology</h3><p>Xiamen University, China</p></div></article>
        <article><time>2014—2018</time><div><h3>BA in Social Work (Honors) & BA in Literature</h3><p>Sichuan University, China</p></div></article>
      </div>
    </section>

    <section className="interest-band"><div><span>03</span><small>Research Interests / 研究兴趣</small></div><p>Drug policy and governance <i>·</i> Recovery and rehabilitation <i>·</i> Sexualized drug use <i>·</i> Penal–welfare regimes <i>·</i> Judicial social work</p></section>

    <section className="academic-section projects-section">
      <div className="academic-label"><span>04</span><small>Research Projects / 科研项目</small></div>
      <div className="project-list">{projects.map(([date,role,title,meta])=><article key={title}><time>{date}</time><small>{role}</small><h3>{title}</h3><p>{meta}</p></article>)}</div>
    </section>

    <section className="service-wrap">
      <section><div className="academic-label"><span>05</span><small>Academic Service / 学术服务</small></div><div className="service-list"><article><time>2025—至今</time><h3>Editorial Board</h3><p><em>Contemporary Drug Problems</em></p></article><article><time>2025—至今</time><h3>Copy Editor</h3><p><em>The Journal of Chinese Sociology</em></p></article></div></section>
      <section><div className="academic-label"><span>06</span><small>Community Service / 社会服务</small></div><div className="community-list">{community.map(([date,org,role])=><article key={org}><time>{date}</time><h3>{org}</h3><p>{role}</p></article>)}</div></section>
    </section>
    <footer className="detail-footer"><Link href="/">← Return to the platform / 返回平台首页</Link></footer>
  </main>;
}
